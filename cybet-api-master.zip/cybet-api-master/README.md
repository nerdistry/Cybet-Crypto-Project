# cybet-api
CyBet bookmaker decentralized betting platfrom API
