package club.cybet.rstatic.errors;

/**
 * cybet-api (club.cybet.rstatic.errors)
 * Created by: cybet
 * On: 14 Aug, 2018 8/14/18 10:51 PM
 **/
public class ErrorsPkgLocator {
}
